import Modal from "./Modal";

export default class ProductModal extends Modal {
  constructor() {
    super(
      "New Product",
      `
        <form class="modal-form">
            <div class="form-control">
                <label>Product Name</label>
                <input type="text" placeholder="Put the name here...">
            </div>
            <div class="form-control">
                <label>Product Description</label>
                <textarea type="text" rows="6" placeholder="Put the description here..."></textarea>
            </div>
            <div class="form-control">
                <label>Product Photos</label>
                <div class="photo-inputs">
                    <input type="text" placeholder="Put the photo url here...">
                </div>
                <button type="button" class="btn btn-primary" id="newPhoto">New Photo</button>
            </div>
            <div class="form-control">
                <label>Product Price</label>
                <input type="number" min="1" placeholder="Put the price with euros here...">
            </div>
            <div class="form-control">
                <label>Product Delivery Time</label>
                <input type="number" min="1" placeholder="Put the delivery time here as number of days...">
            </div>
            <div class="form-control">
                <label>Product Fid Points</label>
                <input type="number" placeholder="Put the fid points here...">
            </div>
            <div class="form-submit">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    `
    );
  }
}
