import Modal from "./Modal";

export default class RewardModal extends Modal {
  constructor() {
    super(
      "New Reward",
      `
        <form class="modal-form">
            <div class="form-control">
                <label>Product To Be Rewarded</label>
                <select>
                    <option value="Test">Test</option>
                    <option value="Test">Test</option>
                    <option value="Test">Test</option>
                    <option value="Test">Test</option>
                </select>
            </div>
            <div class="form-control">
                <label>Required Fid Points</label>
                <input type="number" placeholder="Put the required fid points here...">
            </div>
            <div class="form-submit">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    `
    );
  }
}
