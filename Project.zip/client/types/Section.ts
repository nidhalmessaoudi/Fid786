type Section = "HOME" | "STORE" | "PRODUCT" | "REWARD" | "ORDER";

export default Section;
