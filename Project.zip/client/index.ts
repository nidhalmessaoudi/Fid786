import Main from "./Main";

window.addEventListener("load", () => Main.main());
